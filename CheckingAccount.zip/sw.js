const CACHE = "checking-v1";
const ASSETS = ["/", "/index.html", "/manifest.json", "/icon.svg",
  "https://cdnjs.cloudflare.com/ajax/libs/react/18.2.0/umd/react.production.min.js",
  "https://cdnjs.cloudflare.com/ajax/libs/react-dom/18.2.0/umd/react-dom.production.min.js"
];

self.addEventListener("install", ev => {
  ev.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", ev => {
  ev.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});

self.addEventListener("fetch", ev => {
  ev.respondWith(caches.match(ev.request).then(cached => cached || fetch(ev.request).then(res => {
    if(res && res.status === 200 && res.type !== "opaque") {
      const clone = res.clone();
      caches.open(CACHE).then(c => c.put(ev.request, clone));
    }
    return res;
  }).catch(() => caches.match("/index.html"))));
});
